#!/bin/bash
#SBATCH --job-name=cp2k-LZC
#SBATCH -N 1
#SBATCH -n 48              # cpu cores, suggest < 36
#SBATCH --mem-per-cpu=1GB  # mem/core, suggest < 2 GB
#SBATCH --cpus-per-task=1
#SBATCH --output=%j.log
#SBATCH --partition=amd192c
#SBATCH -t 1-00:00

module load apps/cp2k/2025.1
export OMP_NUM_THREADS=1
export OMP_STACKSIZE=30G
inp_files=$(ls *.inp 2>/dev/null)

for file in $inp_files; do
    echo "Processing file: $file"
    mpirun -np 48 cp2k.psmp -i $file > $file.out
done


